const $ = id => document.getElementById(id);
let history = [], busy = false;
const welcome = "Hi! I'm your English practice partner.\n\nMau lebih percaya diri berbahasa Inggris? Kita mulai dari satu kalimat. Pilih mode belajar di sebelah kiri, lalu ceritakan apa yang ingin kamu latih hari ini.";
function bubble(role, text) {
  const wrap = document.createElement('article'); wrap.className = 'message ' + role;
  const avatar = document.createElement('div'); avatar.className = 'avatar'; avatar.textContent = role === 'user' ? 'U' : 'L';
  const content = document.createElement('div'); content.className = 'bubble';
  const title = document.createElement('span'); title.className = 'speaker'; title.textContent = role === 'user' ? 'YOU' : 'LIA ENGLISH COACH';
  content.append(title, document.createTextNode(text)); wrap.append(avatar, content); $('chat').append(wrap); wrap.scrollIntoView({block:'nearest'});
}
function reset() { history=[]; $('chat').replaceChildren(); bubble('model', welcome); $('error').textContent=''; }
function demoReply(message) {
  if (/yesterday.*go/i.test(message)) return "A small change makes it right!\n\n✓ Yesterday I went to the office.\n\nKarena kejadiannya sudah berlalu (yesterday), gunakan simple past. Bentuk lampau dari go adalah went, bukan goed.\n\nYour turn: What did you do after work yesterday?";
  if (/excit/i.test(message)) return "Excited describes how you feel. Exciting describes something that makes you feel that way.\n\n• I'm excited about the concert.\n• The concert is exciting.\n\nDalam bahasa Indonesia: kamu merasa antusias (excited), sedangkan konsernya seru (exciting).\n\nYour turn: The movie was so ___. I felt ___!";
  if (/interview/i.test(message)) return "Let's practice! I'll be the interviewer, and you'll be the candidate.\n\nGood morning. Thank you for coming today. Could you tell me a little about yourself and why you're interested in this role?";
  return "Ini respons demo terprogram. Demo tersedia untuk tiga tombol contoh di bawah.\n\nUntuk membahas pesanmu secara bebas, pasang GEMINI_API_KEY di file .env, restart server, lalu matikan mode demo. Pengaturan level, gaya, temperature, dan memory diterapkan pada mode Gemini.";
}
$('temperature').oninput = () => $('temp-value').textContent = $('temperature').value;
$('reset').onclick = reset;
$('demo').onchange = () => {reset(); $('status').textContent = $('demo').checked ? 'DEMO' : 'GEMINI API'; $('notice').textContent = $('demo').checked ? 'Mode demo • Respons contoh terprogram, bukan hasil Gemini. Matikan mode demo untuk menggunakan AI.' : 'Mode Gemini • Pesan dan konteks yang diaktifkan dikirim ke Google untuk diproses. Jangan masukkan data rahasia.';};
$('export').onclick = () => {
  const data = {mode: $('demo').checked ? 'demo-scripted' : 'gemini', exportedAt: new Date().toISOString(), history};
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type:'application/json'}));
  const a = document.createElement('a'); a.href=url; a.download='english-coach-chat.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
};
$('form').onsubmit = async e => {
  e.preventDefault(); if (busy) return;
  const message = $('message').value.trim(); if (!message) return;
  const config = Object.fromEntries(['mode','level','tone','language','temperature','tokens'].map(id=>[id,$(id).value]));
  busy=true; $('error').textContent='';
  document.querySelectorAll('button,select,input').forEach(x=>x.disabled=true); $('send').textContent='Menjawab…';
  bubble('user', message);
  try {
    let answer;
    if ($('demo').checked) answer=demoReply(message);
    else {
      const res = await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message,config,history:$('memory').checked ? history.slice(-12) : []})});
      const data=await res.json(); if (!res.ok) throw new Error(data.error || 'Permintaan gagal.'); answer=data.text;
    }
    history.push({role:'user',text:message},{role:'model',text:answer}); history=history.slice(-100);
    bubble('model',answer); $('message').value='';
  } catch(err) {
    $('chat').lastElementChild?.remove();
    $('error').textContent=err.message + ' Pesan tetap tersedia untuk dicoba kembali.';
  } finally {
    busy=false; document.querySelectorAll('button,select,input').forEach(x=>x.disabled=false); $('send').textContent='Kirim ↗'; $('message').focus();
  }
};
$('message').onkeydown = e => {if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('form').requestSubmit();}};
document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>{$('message').value=b.dataset.prompt;$('message').focus();});
reset();
fetch('/api/status').then(r=>r.json()).then(d=>{$('connection').textContent = d.configured ? `API key terpasang • ${d.model}. Koneksi belum diuji.` : 'API key belum diisi. Mode demo siap dicoba.';}).catch(()=>{$('connection').textContent='Server tidak terhubung. Jalankan python app.py.';});
