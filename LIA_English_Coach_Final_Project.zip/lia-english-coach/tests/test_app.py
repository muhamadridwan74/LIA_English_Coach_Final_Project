import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from app import prepare, generate

class AppTests(unittest.TestCase):
    def test_parameters_and_memory(self):
        p = prepare({'message':'Why?', 'config':{'level':'A2','temperature':0.3,'tokens':512}, 'history':[{'role':'user','text':'Hi'},{'role':'model','text':'Hello'}]})
        self.assertEqual(len(p['contents']), 3)
        self.assertEqual(p['generationConfig'], {'temperature':0.3,'maxOutputTokens':512})
        self.assertIn('CEFR A2',p['systemInstruction']['parts'][0]['text'])
    def test_invalid_inputs(self):
        for data in [[], {'message':''}, {'message':'a'*3001}, {'message':'Hi','config':{'temperature':float('nan')}}, {'message':'Hi','history':[{'role':'model','text':'hello'}]}]:
            with self.subTest(data=str(data)[:60]), self.assertRaises((ValueError,TypeError)):
                prepare(data)
    @patch.dict('os.environ', {'GEMINI_API_KEY':'test-only'})
    @patch('urllib.request.urlopen')
    def test_request_and_response(self, mock):
        mock.return_value.__enter__.return_value.read.return_value = json.dumps({'candidates':[{'content':{'parts':[{'text':'Hello'}]}}]}).encode()
        self.assertEqual(generate(prepare({'message':'Hi'})), 'Hello')
        request = mock.call_args.args[0]
        self.assertEqual(request.get_header('X-goog-api-key'), 'test-only')
        self.assertNotIn('test-only', request.full_url)
    @patch.dict('os.environ', {'GEMINI_API_KEY':'test-only'})
    @patch('urllib.request.urlopen', side_effect=HTTPError('url',429,'quota',{},None))
    def test_quota(self, mock):
        with self.assertRaisesRegex(RuntimeError,'Kuota'):
            generate(prepare({'message':'Hi'}))
    @patch.dict('os.environ', {'GEMINI_API_KEY':''})
    def test_missing_key(self):
        with self.assertRaisesRegex(RuntimeError,'belum diisi'):
            generate(prepare({'message':'Hi'}))

if __name__ == '__main__': unittest.main()
